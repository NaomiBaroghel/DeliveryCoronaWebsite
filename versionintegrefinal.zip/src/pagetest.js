import React from 'react';

const Ptest= () => (
  <div className='background'>
  <div className = 'about fadeInDown'>
    <h1 className = "fadeIn">TESTTT</h1>
   </div>
  </div>
);

export default Ptest;
