import React from 'react';

const About = () => (
  <div className='background'>
  <div className = 'about fadeInDown'>
    <h1 className = "fadeIn">About US</h1>
    <p className = "fadeIn second">    Take care of yourself while staying at home!</p>
    <p className = "fadeIn third">
Delivery Corona aims to help the population in this time of crisis.
With home delivery, we are helping to protect everyone and reduce the spread of the virus.</p>
    </div>
  </div>
);

export default About;
