import React from 'react';
import logo from './volantmain.png';

const Home = () => (
  <div className='background '>
    <h1 className ="fadeIn">Welcome to the Delivery Corona website.</h1>
    <p className ="fadeIn"> Feel free to browse around and learn more about us.</p>
<img src={logo} className="App-logo" alt="logo" />
  </div>
);

export default Home;
